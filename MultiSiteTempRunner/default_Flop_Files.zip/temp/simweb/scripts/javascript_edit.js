﻿/*
 * javascript_edit.js - Javascript file used for editing the pages.
 */

var button = new Array();
var values = new Array();
var cur_page;               /* current page (1..nr_pages)        */
var nr_pages;               /* number of pages                   */
var last_page_size;         /* size of the last button page      */

var BTN_BACK_TEXT = "Back"; // Static text

function init() {
  /* check if function is specified */
  if (window.preInit) { 
    preInit();
  }
  
  /* check if function is specified */
  if (window.initButtons) { 
    initButtons();
  } else {
    if (top.viewmode == 1) {
      nav_type = 0;
    } else {
      nav_type = 1;
    }
    printEditNav();
    return 0;
  }

  /* if not specified, set default to 18 */
  if (!window.nr_buttons) {
    nr_buttons = 18; 
  }
  
  /* if not specified, set default to 1 (only a "back" button) */
  if (!window.nav_type) {
    nav_type = 1;
  }
  
  /* if not specified, set default to 1 (small square buttons) */
  if (!window.button_type) {
    button_type = 1; 
  }
  
  /* if not specified, set values to default values */
  if (values.length < button.length) {
    for (var i = 0; i < button.length; i++) {
      values[i] = i;
    }
  }
  
  /* check if view mode is pc and disable the navigation bar */
  if (top.viewmode == 1) {
    nav_type = 0;
    nr_buttons = button.length;
  }

  nr_pages = parseInt(button.length / nr_buttons);
  last_page_size = (parseInt(button.length % nr_buttons)) ? (parseInt(button.length % nr_buttons)) : 0;
  nr_pages = last_page_size ? (nr_pages + 1) : nr_pages;

  /* show the first page */
  displayButtons(1);
  
  /* show the navigation bar */
  printEditNav();
}

function doDone(value) {
  /* set the POST variables and submit the page */
  document.settingstable.par_value.value = value;
  document.settingstable.submit();    
}

function doEscape() {
  /* send a POST request with no variables */
  document.escapetable.submit();    
}

function displayButtons(page) {
  var i;
  var text = "";
  
  /* update the current page number */
  cur_page = page;
  
  text += '<ul>';

  var from_button = (page - 1) * nr_buttons;
  var to_button = (page * nr_buttons);

  for (i = from_button; i < to_button; i++) {
    if (i < button.length) {
      /* set a button with the doDone javascript function */
      if (button_type == 1) {
        text += '<li><button type="button" onclick=\'doDone("' + values[i] + '")\'>' + button[i] + '</button></li>';
      } else if (button_type == 2) {
        text += '<li><button class="big" type="button" onclick=\'doDone("' + values[i] + '")\'>' + button[i] + '</button></li>';
      }
    } else {
      /* set a "dummy" button for small buttons for a nice page alignment */
      if (button_type == 1) {
        text += '<li><button type="button" class="dummybutton"> </button></li>';
      }
    }
  }
  
  text += '</ul>';
  
  /* put everything in the button_div */
  var button_div = document.getElementById('button_div'); 
  button_div.innerHTML = text;
}

function printEditNav() {
  /* use an array because it is faster */
  var s = new Array();
  
  switch (nav_type) {
    /* do not show a navigation bar */
    case 0:
      s.push('');
      break;
    
    /* navigation bar with "back" << [1/3] >> */
    case 2:
      s.push('<form name="NavForm">');
      s.push('<table cellpadding="0" cellspacing="0" border="0" width="100%">');
      s.push('<tr><td align="left">');
      s.push('<button type="button" class="big" OnClick="doEscape()">Back</button>');
      s.push('</td><td align="center" width="100%">');
      s.push('<button type="button" OnClick="doNavBack()"><<</button>');
      s.push('<input type="text" name="tekst">');
      s.push('<button type="button" OnClick="doNavForward()">>></button>');
      s.push('</td><td align="right"><div style="width: 86px"></div>');
      s.push('</td></tr>');
      s.push('</table>');
      s.push('</form>');
      break;
    
    /* navigation bar with "back" */
    default:
      s.push('<form name="NavForm">');
      s.push('<table cellpadding="0" cellspacing="0" border="0" width="100%">');
      s.push('<tr><td align="left">');
      s.push('<button type="button" class="big" OnClick="doEscape()">Back</button>');
      s.push('</td></tr>');
      s.push('</table>');
      s.push('</form>');
      break;
  }

  /* convert the array to a big string and replace the content in the <div id="nav"> element */
  var nav_div = document.getElementById('nav'); 
  nav_div.innerHTML = s.join('');

  /* update the [1/3] text in the navigation bar */
  printNavText();
}

function doNavBack() {
  if (cur_page > 1) {
    /* display the previous page */
    displayButtons(cur_page - 1);
  }
  
  /* update the navigation text */
  printNavText();
}

function doNavForward() {
  if (cur_page < nr_pages) {
    /* display the next page */
    displayButtons(cur_page + 1);
  }

  /* update the navigation text */
  printNavText();
}

function printNavText() {
  /* only update the navigation bar when enabled */
  if (nav_type > 0) {
    document.NavForm.tekst.value = "" + cur_page + "/" + nr_pages;
  }
}